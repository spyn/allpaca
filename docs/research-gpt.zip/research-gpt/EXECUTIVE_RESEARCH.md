# Heterogeneous Local Inference Engine — Deep Research Review

**Research date:** 2026-08-15  
**Target reference platform:** Ryzen 7 5800X-class 8C/16T host, 80+ GB DDR4, Radeon RX 9070 16 GB + Radeon RX 9060 XT 16 GB, optional Google Coral Edge TPU.

## Executive conclusion

The original opportunity list mixes four different categories:

1. **Already implemented in leading engines:** speculative decoding, n-gram speculation, tree verification, disaggregated prefill/decode, paged/prefix KV caching, structured generation, and CPU/GPU overlap.
2. **Feasible but under-integrated on a heterogeneous desktop:** asymmetric dual-GPU scheduling, explicit host-memory model/expert staging, multi-tier KV caching, asynchronous CPU-side constrained decoding, and modality-specific GPU residency.
3. **Model/training dependent research features:** true early exit, self-speculative LayerSkip-style execution, custom tree drafters, and native ternary kernels.
4. **Future hardware research:** CXL memory/PNM/PIM, HBM-PIM, silicon photonics, and true accelerator-coherent memory fabrics.

The most important correction is that **GPU logits cannot generally be DMA'd “directly into the CPU L3 cache” as a software-controlled destination**. PCIe/CXL can provide coherent memory semantics in supported systems, but ordinary discrete GPUs do not expose the CPU cache as a programmable DMA target. The practical substitute is a pinned, cache-conscious host ring buffer with asynchronous device-to-host copies, or a future CXL Type-2 accelerator design.

A second correction is that **32 GB of dual-GPU VRAM is not one automatically pooled 32 GB address space**. HIP supports peer-to-peer access where the topology and driver expose it, but allocation, placement and communication remain explicit. AMD documents P2P GPU access and notes that otherwise copies can fall back through host staging. [AMD HIP multi-device documentation](https://rocm.docs.amd.com/projects/HIP/en/develop/how-to/hip_runtime_api/multi_device.html)

A third correction is that **1F1B is a training/pipeline-parallelism term**; an inference engine should instead implement a decode/prefill pipeline with microbatching and double buffering. Backward-pass terminology should not be copied into a pure generation scheduler.

## Opportunity matrix

| Opportunity | Status in current engines/research | Target engine decision | Feasibility here |
|---|---|---|---|
| Draft-model speculative decoding | Productized in llama.cpp/vLLM/SGLang | Implement baseline first | High |
| n-gram speculation | Productized in llama.cpp | Keep as zero-cost fallback | High |
| Tree speculative verification | Research/product components exist | Build heterogeneous tree scheduler | High/Medium |
| EAGLE/MTP/self-speculation | Increasingly productized | Plugin architecture | Medium |
| Prefill/decode disaggregation | Productized in vLLM ecosystems | Implement local asymmetric variant | High |
| CPU/GPU overlap + async sampling | Common pattern | Make first-class scheduler primitive | High |
| Early exit | Research/model-dependent | Only for trained early-exit models | Medium/Low |
| Host RAM weight/expert staging | Established in offload systems | Implement page cache + async prefetch | High |
| NVMe KV/weight tier | Research/throughput-oriented systems | Optional cold tier | Medium |
| “GPU directly to L3” logits | Not a normal PCIe GPU facility | Reject literal design; replace with ring-buffer DMA | Not applicable |
| GPU P2P DMA | Supported by HIP when topology permits | Detect and exploit | High |
| GPU memory pooling as transparent 32 GB | Not transparent | Explicit device-local allocators | High |
| Coral Edge TPU as generic LLM draft engine | Wrong abstraction; op-limited TFLite | Restrict to small compiled classifiers | Medium |
| Coral structured-output arbiter | Not inherently useful | CPU SIMD is usually preferable | Low |
| Multimodal GPU partitioning | Feasible | Permanent modality residency | High |
| Infinity Cache software “locking” | Not directly exposed | Tune kernels, do not assume residency | Medium |
| Native ternary/BitNet backend | Real and advancing | Dedicated model backend | Medium |
| CXL memory tier | Real server hardware/research | Architecture extension, not desktop MVP | Low here |
| HBM-PIM/PNM | Research/accelerator products | Future backend interface | Not on desktop |
| Photonic compute/interconnect | Hardware research/productization | Future accelerator abstraction | Not on desktop |

## Key research findings

### 1. Speculative decoding is no longer an untouched opportunity

llama.cpp currently supports draft-model speculation, n-gram variants, EAGLE3, MTP and configurable speculative-device placement. Its server and common APIs expose draft-model controls directly. This means a new engine should not waste effort cloning a basic linear drafter; its differentiator should be **policy selection, heterogeneous placement, acceptance-aware scheduling, and multi-path/tree orchestration**.

Sources: [llama.cpp speculative decoding](https://github.com/ggml-org/llama.cpp/blob/master/docs/speculative.md), [llama.cpp CLI options](https://github.com/ggml-org/llama.cpp/blob/master/tools/cli/README.md).

### 2. Tree verification is a legitimate high-value extension

SpecInfer and Medusa demonstrated tree-based candidate generation/verification. The value is not “parallel branches by themselves”; it is reducing sequential target-model decode steps while preserving target-model semantics. [SpecInfer](https://arxiv.org/abs/2305.09781), [Medusa](https://arxiv.org/abs/2401.10774).

The engine should therefore use a **Token Forest** abstraction with:

- node token IDs,
- parent index,
- depth,
- cumulative draft score,
- attention-mask ancestry,
- source/drafter ID,
- expected verification cost.

### 3. Disaggregated prefill/decode is already mainstream enough to be a design primitive

vLLM explicitly documents disaggregated prefill, including KV transfer connectors and remote decode instances. It also notes that the main benefit is tail inter-token latency control rather than automatic throughput increase. The new engine should therefore differentiate **throughput objectives** from **tail-latency objectives** in its scheduler. [vLLM disaggregated prefill](https://github.com/vllm-project/vllm/blob/main/docs/features/disagg_prefill.md).

### 4. Early exit must be model-aware

LayerSkip shows that useful early exit requires models trained for early exits/self-speculation. A generic runtime cannot safely look at entropy halfway through an arbitrary model, abort the remaining layers, and assume the result is equivalent. [LayerSkip paper](https://arxiv.org/abs/2404.16710), [official implementation](https://github.com/facebookresearch/LayerSkip).

Therefore the runtime should expose an `EarlyExitPolicy`, but only enable it when the model manifest declares a valid exit head/calibration scheme.

### 5. Host/NVMe tiering is real; latency matters

FlexGen demonstrated explicit allocation across GPU, CPU and disk, with overlap-aware scheduling. More recent work has characterized NVMe traffic for model and KV offload. This supports an explicit **three-tier page cache**, but NVMe should be treated as a cold-capacity extension rather than pretending it behaves like VRAM. [FlexGen](https://github.com/tomaarsen/FlexGen), [CHEOPS 2025 study](https://research.ibm.com/publications/an-io-characterizing-study-of-offloading-llm-models-and-kv-caches-to-nvme-ssd).

### 6. CXL is highly relevant architecturally, but not for this motherboard as a software toggle

Recent research such as LIA and CXL-enabled KV-cache systems shows real gains from CXL memory and cooperative CPU/accelerator execution. CXL.cache/CXL.mem provide coherent protocols for suitable hardware. That does **not** imply the current Radeon/AM4 desktop can turn system DDR into transparent coherent GPU HBM or address CPU L3 as a DMA buffer. [LIA](https://deepmind.google/research/publications/81986/), [Linux CXL protocol documentation](https://www.kernel.org/doc/html/latest/driver-api/cxl/devices/device-types.html).

### 7. PIM is credible research, but should be an accelerator abstraction

Recent work proposes heterogeneous SRAM-PIM/HBM-PIM or CXL-PNM systems for LLM inference. These are architectural research platforms, not software capabilities that can be switched on in a desktop GPU. [HPIM](https://arxiv.org/abs/2509.12993), [CXL-PNM KV management](https://arxiv.org/abs/2511.00321).

### 8. BitNet is now a practical software research target

Microsoft's bitnet.cpp is an official inference framework with CPU and GPU kernels for native ~1.58-bit models, including an official 2B/4T model. The right opportunity is not “make ordinary FP16 weights ternary at runtime”; it is a dedicated model/backend path for weights trained in the ternary format. [bitnet.cpp](https://github.com/microsoft/BitNet), [BitNet 2B/4T model](https://huggingface.co/microsoft/bitnet-b1.58-2B-4T).

### 9. Coral is useful as a side accelerator, not as a magical LLM co-processor

The Edge TPU executes compiled TensorFlow Lite models and only supports a documented operation subset; unsupported operators fall back to CPU. This makes it suitable for small classifiers, wake-word models, image detectors and other fixed INT8 graphs. It is not a drop-in general LLM draft-model accelerator. [Coral inference overview](https://www.coral.withgoogle.com/docs/edgetpu/inference/), [supported operations](https://www.coral.withgoogle.com/docs/edgetpu/models-intro/).

### 10. The Radeon pair is strongly asymmetric

AMD lists the RX 9070 at 16 GB, 256-bit, up to 640 GB/s and 64 MB Infinity Cache; the RX 9060 XT 16 GB is 128-bit, up to 320 GB/s and 32 MB Infinity Cache. The engine should therefore prefer **9070 = target / main decoder** and **9060 XT = draft / vision / auxiliary work**, unless a benchmark demonstrates a better split. [RX 9070](https://www.amd.com/en/products/graphics/desktops/radeon/9000-series/amd-radeon-rx-9070.html), [RX 9060 XT 16 GB](https://www.amd.com/en/products/graphics/desktops/radeon/9000-series/amd-radeon-rx-9060xt.html).

## Recommended MVP order

1. Device topology discovery and explicit P2P tests.
2. Asymmetric target/draft scheduling.
3. Token Forest + tree verification.
4. Prefill/decode separation inside one machine.
5. Pinned host-memory ring buffers and async sampling/masking.
6. Host RAM model/expert page cache.
7. Hierarchical KV cache: VRAM -> pinned/regular DDR -> NVMe.
8. Multimodal placement.
9. Structured output scheduler.
10. Early-exit/self-speculation only for compatible checkpoints.
11. BitNet backend.
12. Coral sidecar plugin.
13. CXL/PIM simulator/plugin interface.
14. Photonic/remote-accelerator interface.

## What should be removed or rewritten from the original proposal

- Replace “direct-to-L3” with “asynchronous pinned-memory logits transport”.
- Replace “VRAM pool” with “explicit cross-device memory fabric”.
- Replace “CPU sends CUDA abort interrupt” with “model-specific early-exit graph path”.
- Replace “1F1B inference” with “inference microbatch pipeline / double buffering”.
- Replace “Infinity Cache clamp” with “cache-aware kernel tiling and measured cache locality”.
- Replace “Coral as generic JSON arbiter” with “Coral fixed-function sidecar inference plugin”.
- Replace “GPUDirect Storage on Radeon” with “backend-neutral direct-I/O interface; NVIDIA GDS implementation is optional, AMD desktop MVP uses async host staging”.
